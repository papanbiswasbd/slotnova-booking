/**
 * SlotNova Booking Admin JavaScript
 *
 * @package SlotNova\Booking
 * @version 1.0.0
 */

jQuery(document).ready(function($) {
	'use strict';

	/* -------------------------------------------------------------------------
	 * 1. Dashboard Chart (Chart.js)
	 * ------------------------------------------------------------------------- */
	if (typeof slotnova_admin_data !== 'undefined' && slotnova_admin_data.chart) {
		var chartEl = document.getElementById('slotnovaBookingsChart');
		if (chartEl && typeof Chart !== 'undefined') {
			var ctx = chartEl.getContext('2d');
			new Chart(ctx, {
				type: 'line',
				data: {
					labels: slotnova_admin_data.chart.labels,
					datasets: [{
						label: slotnova_admin_data.chart.i18n_label,
						data: slotnova_admin_data.chart.values,
						borderColor: '#2271b1',
						backgroundColor: 'rgba(34, 113, 177, 0.1)',
						borderWidth: 2,
						fill: true,
						tension: 0.3
					}]
				},
				options: {
					responsive: true,
					scales: {
						y: {
							beginAtZero: true,
							ticks: { stepSize: 1 }
						}
					}
				}
			});
		}

		// Auto submit dashboard date filter dropdown
		$(document).on('change', '.slotnova-filter-select', function() {
			$(this).closest('form').submit();
		});
	}

	/* -------------------------------------------------------------------------
	 * 2. Bookings Calendar (FullCalendar & Tab Switching)
	 * ------------------------------------------------------------------------- */
	var tabList = document.getElementById('slotnova-tab-list-view');
	var tabCal = document.getElementById('slotnova-tab-calendar-view');
	var containerList = document.getElementById('slotnova-list-view-container');
	var containerCal = document.getElementById('slotnova-calendar-view-container');
	var calendarEl = document.getElementById('slotnova-fullcalendar');
	var calendarInitialized = false;

	if (tabList && tabCal) {
		tabList.addEventListener('click', function(e) {
			e.preventDefault();
			tabList.classList.add('nav-tab-active');
			tabCal.classList.remove('nav-tab-active');
			containerList.style.display = 'block';
			containerCal.style.display = 'none';
		});

		tabCal.addEventListener('click', function(e) {
			e.preventDefault();
			tabCal.classList.add('nav-tab-active');
			tabList.classList.remove('nav-tab-active');
			containerList.style.display = 'none';
			containerCal.style.display = 'block';

			if (!calendarInitialized && typeof FullCalendar !== 'undefined' && calendarEl) {
				var eventsData = (typeof slotnova_admin_data !== 'undefined' && slotnova_admin_data.calendar) ? slotnova_admin_data.calendar.events : [];
				var calendar = new FullCalendar.Calendar(calendarEl, {
					initialView: 'dayGridMonth',
					headerToolbar: {
						left: 'prev,next today',
						center: 'title',
						right: 'dayGridMonth,timeGridWeek,timeGridDay'
					},
					events: eventsData
				});
				calendar.render();
				calendarInitialized = true;
			}
		});
	}

	/* -------------------------------------------------------------------------
	 * 3. Flatpickr (Global Settings & Product Slot Manager)
	 * ------------------------------------------------------------------------- */
	if (typeof flatpickr !== 'undefined') {
		if ($('#slotnova_specific_off_days').length) {
			flatpickr("#slotnova_specific_off_days", {
				mode: "multiple",
				dateFormat: "Y-m-d"
			});
		}
		if ($('#_slotnova_specific_off_days').length) {
			flatpickr("#_slotnova_specific_off_days", {
				mode: "multiple",
				dateFormat: "Y-m-d"
			});
		}
	}

	/* -------------------------------------------------------------------------
	 * 4. Product Tab Repeaters (Services & Employees)
	 * ------------------------------------------------------------------------- */
	var defaultServicePrices = (typeof slotnova_admin_data !== 'undefined' && slotnova_admin_data.default_service_prices) ? slotnova_admin_data.default_service_prices : {};

	// Auto-fill price when a service is selected
	$('body').on('change', '.slotnova-service-select', function() {
		var termId = $(this).val();
		var priceInput = $(this).closest('tr').find('.slotnova-service-price-input');
		if (termId && defaultServicePrices[termId] !== undefined) {
			priceInput.val(defaultServicePrices[termId]);
		}
	});

	// Make repeater tables sortable
	if ($('#slotnova-services-table tbody').length) {
		$('#slotnova-services-table tbody').sortable({ handle: '.slotnova-drag-handle' });
	}
	if ($('#slotnova-employees-table tbody').length) {
		$('#slotnova-employees-table tbody').sortable({ handle: '.slotnova-drag-handle' });
	}

	// Remove row
	$('body').on('click', '.slotnova-remove-row', function(e) {
		e.preventDefault();
		$(this).closest('tr').remove();
	});

	// Add Service Row
	$('#slotnova-add-service').on('click', function(e) {
		e.preventDefault();
		if (typeof slotnova_admin_data === 'undefined') return;

		var optionsHtml = '<option value="">' + slotnova_admin_data.i18n.select_service + '</option>';
		$.each(slotnova_admin_data.all_services, function(id, name) {
			optionsHtml += '<option value="' + id + '">' + name + '</option>';
		});

		var row = '<tr>' +
			'<td class="slotnova-drag-handle">☰</td>' +
			'<td><select name="slotnova_repeater_service_id[]" class="slotnova-table-select slotnova-service-select">' + optionsHtml + '</select></td>' +
			'<td><input type="number" name="slotnova_repeater_service_price[]" value="" step="0.01" min="0" class="slotnova-table-input-price slotnova-service-price-input"></td>' +
			'<td class="slotnova-align-center"><a href="#" class="slotnova-remove-row" title="' + slotnova_admin_data.i18n.remove + '"><span class="dashicons dashicons-trash"></span></a></td>' +
			'</tr>';

		$('#slotnova-services-table tbody').append(row);
	});

	// Add Employee Row
	$('#slotnova-add-employee').on('click', function(e) {
		e.preventDefault();
		if (typeof slotnova_admin_data === 'undefined') return;

		var optionsHtml = '<option value="">' + slotnova_admin_data.i18n.select_employee + '</option>';
		$.each(slotnova_admin_data.all_employees, function(id, name) {
			optionsHtml += '<option value="' + id + '">' + name + '</option>';
		});

		var row = '<tr>' +
			'<td class="slotnova-drag-handle">☰</td>' +
			'<td><select name="slotnova_repeater_employee_id[]" class="slotnova-table-select">' + optionsHtml + '</select></td>' +
			'<td class="slotnova-align-center"><a href="#" class="slotnova-remove-row" title="' + slotnova_admin_data.i18n.remove + '"><span class="dashicons dashicons-trash"></span></a></td>' +
			'</tr>';

		$('#slotnova-employees-table tbody').append(row);
	});

	/* -------------------------------------------------------------------------
	 * 5. Media Uploader for Taxonomy Term Images
	 * ------------------------------------------------------------------------- */
	$('body').on('click', '.slotnova-upload-image-button', function(e) {
		e.preventDefault();
		var button = $(this);
		var inputField = button.siblings('.slotnova-image-id');
		var previewImg = button.siblings('.slotnova-image-preview');

		var customUploader = wp.media({
			title: (typeof slotnova_admin_data !== 'undefined' && slotnova_admin_data.i18n) ? slotnova_admin_data.i18n.choose_image : 'Choose Image',
			button: { text: (typeof slotnova_admin_data !== 'undefined' && slotnova_admin_data.i18n) ? slotnova_admin_data.i18n.use_image : 'Use Image' },
			multiple: false
		}).on('select', function() {
			var attachment = customUploader.state().get('selection').first().toJSON();
			inputField.val(attachment.id);
			previewImg.attr('src', attachment.url).removeClass('slotnova-is-hidden').show();
			button.siblings('.slotnova-remove-image-button').removeClass('slotnova-is-hidden').show();
		}).open();
	});

	$('body').on('click', '.slotnova-remove-image-button', function(e) {
		e.preventDefault();
		var button = $(this);
		button.siblings('.slotnova-image-id').val('');
		button.siblings('.slotnova-image-preview').attr('src', '').hide();
		button.hide();
	});

});
