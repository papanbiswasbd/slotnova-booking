<?php
/**
 * SlotNova Admin Class
 *
 * @package SlotNova\Booking
 * @version 1.0.0
 */

namespace SlotNova\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin
 *
 * Handles admin menus, settings, dashboard analytics, and product meta boxes.
 */
class Admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_init', array( $this, 'register_settings_options' ) );

		// Register Product Type
		add_filter( 'product_type_selector', array( $this, 'add_slotnova_product_type' ) );
		add_filter( 'woocommerce_product_class', array( $this, 'woocommerce_product_class' ), 10, 2 );
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_slotnova_product_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_slotnova_product_tab_content' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_slotnova_product_tab_data' ) );
	}

	/**
	 * Add slotnova product type to WooCommerce selector.
	 *
	 * @param array $types Existing product types.
	 * @return array
	 */
	public function add_slotnova_product_type( $types ) {
		$types['slotnova'] = __( 'SlotNova Booking', 'slotnova-booking' );
		return $types;
	}

	/**
	 * Map slotnova product type to our custom class.
	 *
	 * @param string $classname Current class name.
	 * @param string $product_type Product type slug.
	 * @return string
	 */
	public function woocommerce_product_class( $classname, $product_type ) {
		if ( 'slotnova' === $product_type ) {
			$classname = '\\SlotNova\\Booking\\WC_Product';
		}
		return $classname;
	}

	/**
	 * Register global plugin options.
	 *
	 * @return void
	 */
	public function register_settings_options() {
		register_setting( 'slotnova_settings_group', 'slotnova_opening_time', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'slotnova_settings_group', 'slotnova_closing_time', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'slotnova_settings_group', 'slotnova_slot_duration', array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'slotnova_settings_group', 'slotnova_weekly_off_days', array( 'sanitize_callback' => array( $this, 'sanitize_array' ) ) );
		register_setting( 'slotnova_settings_group', 'slotnova_specific_off_days', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'slotnova_settings_group', 'slotnova_enable_time_slots', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	}

	/**
	 * Sanitize array setting.
	 *
	 * @param mixed $input Input data.
	 * @return array
	 */
	public function sanitize_array( $input ) {
		if ( ! is_array( $input ) ) {
			return array();
		}
		return array_map( 'sanitize_text_field', $input );
	}

	/**
	 * Add product data tabs for SlotNova.
	 *
	 * @param array $tabs Existing product data tabs.
	 * @return array
	 */
	public function add_slotnova_product_tab( $tabs ) {
		if ( isset( $tabs['general'] ) ) {
			array_push( $tabs['general']['class'], 'show_if_slotnova' );
		}

		$tabs['slotnova_booking'] = array(
			'label'    => __( 'SlotNova Booking', 'slotnova-booking' ),
			'target'   => 'slotnova_booking_data',
			'class'    => array( 'show_if_slotnova' ),
			'priority' => 25,
		);

		$tabs['slotnova_slot_manager'] = array(
			'label'    => __( 'Slot Manager', 'slotnova-booking' ),
			'target'   => 'slotnova_slot_manager_data',
			'class'    => array( 'show_if_slotnova' ),
			'priority' => 26,
		);
		return $tabs;
	}

	/**
	 * Enqueue admin scripts and styles conditionally.
	 *
	 * @param string $hook The current admin page hook.
	 * @return void
	 */
	public function enqueue_scripts( $hook ) {
		$is_slotnova_page = ( strpos( $hook, 'slotnova' ) !== false );
		$is_product_page  = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

		if ( ! $is_slotnova_page && ! $is_product_page ) {
			return;
		}

		// Always enqueue core admin CSS and JS on relevant pages
		wp_enqueue_style( 'slotnova-admin-css', SLOTNOVA_BOOKING_URL . 'assets/css/slotnova-admin.css', array(), SLOTNOVA_BOOKING_VERSION );
		wp_enqueue_script( 'slotnova-admin-js', SLOTNOVA_BOOKING_URL . 'assets/js/slotnova-admin.js', array( 'jquery' ), SLOTNOVA_BOOKING_VERSION, true );

		$localized_data = array(
			'i18n' => array(
				'select_service'  => __( 'Select Service...', 'slotnova-booking' ),
				'select_employee' => __( 'Select Employee...', 'slotnova-booking' ),
				'remove'          => __( 'Remove', 'slotnova-booking' ),
				'choose_image'    => __( 'Choose Image', 'slotnova-booking' ),
				'use_image'       => __( 'Use this image', 'slotnova-booking' ),
			),
		);

		if ( strpos( $hook, 'slotnova-dashboard' ) !== false ) {
			wp_enqueue_script( 'slotnova-chart-js', SLOTNOVA_BOOKING_URL . 'assets/js/chart.min.js', array(), '4.4.0', true );

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$current_filter = isset( $_GET['date_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['date_filter'] ) ) : 'last_7_days';
			$data           = $this->get_dashboard_data( $current_filter );

			$localized_data['chart'] = array(
				'labels'     => $data['chart_labels'],
				'values'     => $data['chart_values'],
				'i18n_label' => __( 'Bookings Made', 'slotnova-booking' ),
			);
		}

		if ( strpos( $hook, 'slotnova-calendar' ) !== false ) {
			wp_enqueue_script( 'slotnova-fullcalendar-js', SLOTNOVA_BOOKING_URL . 'assets/js/fullcalendar.min.js', array(), '6.1.15', true );
			$data                      = $this->get_all_bookings_data();
			$localized_data['calendar'] = array(
				'events' => $data['events'],
			);
		}

		if ( strpos( $hook, 'slotnova-settings' ) !== false || $is_product_page ) {
			wp_enqueue_style( 'slotnova-flatpickr-css', SLOTNOVA_BOOKING_URL . 'assets/css/flatpickr.min.css', array(), '4.6.13' );
			wp_enqueue_script( 'slotnova-flatpickr-js', SLOTNOVA_BOOKING_URL . 'assets/js/flatpickr.min.js', array(), '4.6.13', true );
		}

		if ( $is_product_page ) {
			wp_enqueue_script( 'jquery-ui-sortable' );

			$all_services           = get_terms( array( 'taxonomy' => 'slotnova_service', 'hide_empty' => false ) );
			$all_employees          = get_terms( array( 'taxonomy' => 'slotnova_employee', 'hide_empty' => false ) );
			$default_service_prices = array();
			$service_options        = array();
			$employee_options       = array();

			if ( ! is_wp_error( $all_services ) && ! empty( $all_services ) ) {
				foreach ( $all_services as $service ) {
					$default_service_prices[ $service->term_id ] = get_term_meta( $service->term_id, 'slotnova_service_price', true );
					$service_options[ $service->term_id ]        = $service->name;
				}
			}

			if ( ! is_wp_error( $all_employees ) && ! empty( $all_employees ) ) {
				foreach ( $all_employees as $employee ) {
					$employee_options[ $employee->term_id ] = $employee->name;
				}
			}

			$localized_data['default_service_prices'] = $default_service_prices;
			$localized_data['all_services']           = $service_options;
			$localized_data['all_employees']          = $employee_options;
		}

		wp_localize_script( 'slotnova-admin-js', 'slotnova_admin_data', $localized_data );
	}

	/**
	 * Register admin menu items.
	 *
	 * @return void
	 */
	public function register_menus() {
		add_menu_page(
			__( 'SlotNova Booking', 'slotnova-booking' ),
			__( 'SlotNova', 'slotnova-booking' ),
			'manage_woocommerce',
			'slotnova-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-calendar-alt',
			54
		);

		add_submenu_page(
			'slotnova-dashboard',
			__( 'Bookings', 'slotnova-booking' ),
			__( 'Bookings', 'slotnova-booking' ),
			'manage_woocommerce',
			'slotnova-calendar',
			array( $this, 'render_calendar' )
		);

		add_submenu_page(
			'slotnova-dashboard',
			__( 'Settings', 'slotnova-booking' ),
			__( 'Settings', 'slotnova-booking' ),
			'manage_woocommerce',
			'slotnova-settings',
			array( $this, 'render_settings' )
		);
	}

	/**
	 * Calculate dashboard metrics.
	 *
	 * @param string $filter Selected filter range.
	 * @return array
	 */
	private function get_dashboard_data( $filter = 'last_7_days' ) {
		$args = array(
			'status' => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
			'limit'  => -1,
		);

		$today_ts  = current_time( 'timestamp' );
		$is_yearly = false;

		switch ( $filter ) {
			case 'this_week':
				$start_date = wp_date( 'Y-m-d', strtotime( 'monday this week', $today_ts ) );
				$end_date   = wp_date( 'Y-m-d', strtotime( 'sunday this week', $today_ts ) );
				break;
			case 'this_month':
				$start_date = wp_date( 'Y-m-01', $today_ts );
				$end_date   = wp_date( 'Y-m-t', $today_ts );
				break;
			case 'last_month':
				$start_date = wp_date( 'Y-m-01', strtotime( 'first day of last month', $today_ts ) );
				$end_date   = wp_date( 'Y-m-t', strtotime( 'last day of last month', $today_ts ) );
				break;
			case 'this_year':
				$start_date = wp_date( 'Y-01-01', $today_ts );
				$end_date   = wp_date( 'Y-12-31', $today_ts );
				$is_yearly  = true;
				break;
			case 'last_year':
				$start_date = wp_date( 'Y-01-01', strtotime( 'last year', $today_ts ) );
				$end_date   = wp_date( 'Y-12-31', strtotime( 'last year', $today_ts ) );
				$is_yearly  = true;
				break;
			case 'last_7_days':
			default:
				$start_date = wp_date( 'Y-m-d', strtotime( '-6 days', $today_ts ) );
				$end_date   = wp_date( 'Y-m-d', $today_ts );
				break;
		}

		$args['date_created'] = $start_date . '...' . $end_date;
		$orders               = wc_get_orders( $args );

		$total_bookings    = 0;
		$total_revenue     = 0;
		$upcoming_bookings = 0;
		$chart_data        = array();

		if ( $is_yearly ) {
			for ( $m = 1; $m <= 12; $m++ ) {
				$month_key                = wp_date( 'Y-m', strtotime( wp_date( 'Y', strtotime( $start_date ) ) . '-' . sprintf( '%02d', $m ) . '-01' ) );
				$chart_data[ $month_key ] = 0;
			}
		} else {
			$current = strtotime( $start_date );
			$end     = strtotime( $end_date );
			while ( $current <= $end ) {
				$chart_data[ wp_date( 'Y-m-d', $current ) ] = 0;
				$current                                    = strtotime( '+1 day', $current );
			}
		}

		$today = wp_date( 'Y-m-d' );

		foreach ( $orders as $order ) {
			foreach ( $order->get_items() as $item ) {
				$booking_date = $item->get_meta( 'Date' );
				if ( ! empty( $booking_date ) ) {
					$total_bookings++;
					$total_revenue += $item->get_total();

					if ( $booking_date >= $today ) {
						$upcoming_bookings++;
					}

					$order_key = $is_yearly ? $order->get_date_created()->date( 'Y-m' ) : $order->get_date_created()->date( 'Y-m-d' );

					if ( isset( $chart_data[ $order_key ] ) ) {
						$chart_data[ $order_key ]++;
					}
				}
			}
		}

		$chart_labels = array();
		foreach ( $chart_data as $key => $val ) {
			if ( $is_yearly ) {
				$chart_labels[] = wp_date( 'M Y', strtotime( $key . '-01' ) );
			} else {
				$chart_labels[] = wp_date( 'M j', strtotime( $key ) );
			}
		}

		return array(
			'total_bookings'    => $total_bookings,
			'total_revenue'     => $total_revenue,
			'upcoming_bookings' => $upcoming_bookings,
			'chart_labels'      => $chart_labels,
			'chart_values'      => array_values( $chart_data ),
		);
	}

	/**
	 * Render Dashboard page.
	 *
	 * @return void
	 */
	public function render_dashboard() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'slotnova-booking' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current_filter = isset( $_GET['date_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['date_filter'] ) ) : 'last_7_days';
		$data           = $this->get_dashboard_data( $current_filter );

		$filter_options = array(
			'this_week'   => __( 'This Week', 'slotnova-booking' ),
			'last_7_days' => __( 'Last 7 Days', 'slotnova-booking' ),
			'this_month'  => __( 'This Month', 'slotnova-booking' ),
			'last_month'  => __( 'Last Month', 'slotnova-booking' ),
			'this_year'   => __( 'This Year', 'slotnova-booking' ),
			'last_year'   => __( 'Last Year', 'slotnova-booking' ),
		);
		?>
		<div class="wrap">
			<div class="slotnova-admin-header">
				<h1><?php esc_html_e( 'SlotNova Dashboard', 'slotnova-booking' ); ?></h1>
				<form method="get" action="">
					<input type="hidden" name="page" value="slotnova-dashboard" />
					<select name="date_filter" class="slotnova-filter-select">
						<?php foreach ( $filter_options as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_filter, $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<noscript><button type="submit" class="button"><?php esc_html_e( 'Filter', 'slotnova-booking' ); ?></button></noscript>
				</form>
			</div>

			<div class="slotnova-dashboard-grid">
				<div class="slotnova-stat-card slotnova-stat-card-blue">
					<h3 class="slotnova-stat-card-title"><?php esc_html_e( 'Total Bookings', 'slotnova-booking' ); ?></h3>
					<p class="slotnova-stat-card-value"><?php echo esc_html( $data['total_bookings'] ); ?></p>
				</div>
				<div class="slotnova-stat-card slotnova-stat-card-green">
					<h3 class="slotnova-stat-card-title"><?php esc_html_e( 'Total Revenue', 'slotnova-booking' ); ?></h3>
					<p class="slotnova-stat-card-value"><?php echo wp_kses_post( wc_price( $data['total_revenue'] ) ); ?></p>
				</div>
				<div class="slotnova-stat-card slotnova-stat-card-yellow">
					<h3 class="slotnova-stat-card-title"><?php esc_html_e( 'Upcoming Bookings', 'slotnova-booking' ); ?></h3>
					<p class="slotnova-stat-card-value"><?php echo esc_html( $data['upcoming_bookings'] ); ?></p>
				</div>
			</div>

			<div class="slotnova-chart-container">
				<h3 class="slotnova-chart-title">
					<?php 
					/* translators: %s: filter label */
					printf( esc_html__( 'Bookings (%s)', 'slotnova-booking' ), esc_html( $filter_options[ $current_filter ] ) ); 
					?>
				</h3>
				<canvas id="slotnovaBookingsChart" height="100"></canvas>
			</div>
		</div>
		<?php
	}

	/**
	 * Get list and calendar event data.
	 *
	 * @return array
	 */
	private function get_all_bookings_data() {
		$args   = array(
			'status' => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
			'limit'  => -1,
		);
		$orders = wc_get_orders( $args );

		$list_data       = array();
		$calendar_events = array();

		foreach ( $orders as $order ) {
			foreach ( $order->get_items() as $item ) {
				$booking_date = $item->get_meta( 'Date' );

				if ( ! empty( $booking_date ) ) {
					$time          = $item->get_meta( 'Time' );
					$service       = $item->get_meta( 'Service' );
					$employee      = $item->get_meta( 'Employee' );
					$customer_name = $order->get_formatted_billing_full_name();
					if ( empty( $customer_name ) ) {
						$customer_name = __( 'Guest', 'slotnova-booking' );
					}

					$list_data[] = array(
						'order_id'  => $order->get_id(),
						'order_url' => $order->get_edit_order_url(),
						'customer'  => $customer_name,
						'email'     => $order->get_billing_email(),
						'phone'     => $order->get_billing_phone(),
						'address'   => str_replace( '<br/>', ', ', $order->get_formatted_billing_address() ),
						'service'   => $service,
						'employee'  => $employee,
						'date'      => $booking_date,
						'time'      => $time,
						'status'    => wc_get_order_status_name( $order->get_status() ),
					);

					$event_title = $customer_name . ' - ' . $service;
					$event_start = $booking_date;
					if ( ! empty( $time ) ) {
						$time_24     = wp_date( 'H:i:s', strtotime( $time ) );
						$event_start .= 'T' . $time_24;
					}

					$calendar_events[] = array(
						'title'           => $event_title,
						'start'           => $event_start,
						'url'             => $order->get_edit_order_url(),
						'backgroundColor' => '#2271b1',
						'borderColor'     => '#2271b1',
					);
				}
			}
		}

		return array(
			'list'   => $list_data,
			'events' => $calendar_events,
		);
	}

	/**
	 * Render Calendar / All Bookings page.
	 *
	 * @return void
	 */
	public function render_calendar() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'slotnova-booking' ) );
		}

		$data = $this->get_all_bookings_data();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'All Bookings', 'slotnova-booking' ); ?></h1>
			<h2 class="nav-tab-wrapper slotnova-nav-tabs">
				<a href="#" class="nav-tab nav-tab-active" id="slotnova-tab-list-view"><?php esc_html_e( 'List View', 'slotnova-booking' ); ?></a>
				<a href="#" class="nav-tab" id="slotnova-tab-calendar-view"><?php esc_html_e( 'Calendar View', 'slotnova-booking' ); ?></a>
			</h2>

			<div id="slotnova-list-view-container">
				<table class="wp-list-table widefat fixed striped table-view-list">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Order ID', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Customer', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Email', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Phone', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Service', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Employee', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Date & Time', 'slotnova-booking' ); ?></th>
							<th><?php esc_html_e( 'Status', 'slotnova-booking' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $data['list'] ) ) : ?>
							<tr>
								<td colspan="8"><?php esc_html_e( 'No bookings found.', 'slotnova-booking' ); ?></td>
							</tr>
						<?php else : ?>
							<?php foreach ( $data['list'] as $booking ) : ?>
								<tr>
									<td><a href="<?php echo esc_url( $booking['order_url'] ); ?>">#<?php echo esc_html( $booking['order_id'] ); ?></a></td>
									<td><strong><?php echo esc_html( $booking['customer'] ); ?></strong></td>
									<td><a href="mailto:<?php echo esc_attr( $booking['email'] ); ?>"><?php echo esc_html( $booking['email'] ); ?></a></td>
									<td><?php echo esc_html( $booking['phone'] ); ?></td>
									<td><?php echo esc_html( $booking['service'] ); ?></td>
									<td><?php echo esc_html( $booking['employee'] ); ?></td>
									<td>
										<?php echo esc_html( wp_date( 'M d, Y', strtotime( $booking['date'] ) ) ); ?>
										<br/>
										<small><?php echo esc_html( $booking['time'] ); ?></small>
									</td>
									<td><span class="mark order-status status-<?php echo sanitize_html_class( strtolower( $booking['status'] ) ); ?>"><span><?php echo esc_html( $booking['status'] ); ?></span></span></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<div id="slotnova-calendar-view-container" class="slotnova-calendar-container slotnova-is-hidden">
				<div id="slotnova-fullcalendar"></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render Global Settings page.
	 *
	 * @return void
	 */
	public function render_settings() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'slotnova-booking' ) );
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'SlotNova Global Settings', 'slotnova-booking' ); ?></h1>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'slotnova_settings_group' );
				do_settings_sections( 'slotnova_settings_group' );

				$opening_time  = get_option( 'slotnova_opening_time', '09:00' );
				$closing_time  = get_option( 'slotnova_closing_time', '17:00' );
				$weekly_off    = get_option( 'slotnova_weekly_off_days', array() );
				if ( ! is_array( $weekly_off ) ) {
					$weekly_off = array();
				}

				$days_of_week = array(
					'Sunday'    => __( 'Sunday', 'slotnova-booking' ),
					'Monday'    => __( 'Monday', 'slotnova-booking' ),
					'Tuesday'   => __( 'Tuesday', 'slotnova-booking' ),
					'Wednesday' => __( 'Wednesday', 'slotnova-booking' ),
					'Thursday'  => __( 'Thursday', 'slotnova-booking' ),
					'Friday'    => __( 'Friday', 'slotnova-booking' ),
					'Saturday'  => __( 'Saturday', 'slotnova-booking' ),
				);
				?>
				<h2><?php esc_html_e( 'Smart Time Slot Generator', 'slotnova-booking' ); ?></h2>
				<table class="form-table">
					<tr valign="top">
						<th scope="row"><?php esc_html_e( 'Enable Time Slots', 'slotnova-booking' ); ?></th>
						<td>
							<fieldset>
								<label>
									<input type="checkbox" name="slotnova_enable_time_slots" value="yes" <?php checked( get_option( 'slotnova_enable_time_slots', 'yes' ), 'yes' ); ?> />
									<?php esc_html_e( 'Enable time slot selection for bookings.', 'slotnova-booking' ); ?>
								</label>
							</fieldset>
							<p class="description"><?php esc_html_e( 'If disabled, customers will only select a Date for their booking.', 'slotnova-booking' ); ?></p>
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><?php esc_html_e( 'Opening Time', 'slotnova-booking' ); ?></th>
						<td>
							<input type="time" name="slotnova_opening_time" value="<?php echo esc_attr( $opening_time ); ?>" />
							<p class="description"><?php esc_html_e( 'When does your business open? (e.g. 09:00 AM)', 'slotnova-booking' ); ?></p>
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><?php esc_html_e( 'Closing Time', 'slotnova-booking' ); ?></th>
						<td>
							<input type="time" name="slotnova_closing_time" value="<?php echo esc_attr( $closing_time ); ?>" />
							<p class="description"><?php esc_html_e( 'When does your business close? (e.g. 05:00 PM)', 'slotnova-booking' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Slot Duration (Minutes)', 'slotnova-booking' ); ?></th>
						<td>
							<input type="number" name="slotnova_slot_duration" value="<?php echo esc_attr( get_option( 'slotnova_slot_duration', '60' ) ); ?>" class="regular-text" step="5" min="5" />
							<p class="description"><?php esc_html_e( 'Duration of each booking slot (e.g., 60 for 1 hour).', 'slotnova-booking' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Off-Days & Vacations', 'slotnova-booking' ); ?></h2>
				<table class="form-table">
					<tr valign="top">
						<th scope="row"><?php esc_html_e( 'Weekly Off-Days', 'slotnova-booking' ); ?></th>
						<td>
							<fieldset>
								<?php foreach ( $days_of_week as $day_key => $day_label ) : ?>
									<label class="slotnova-checkbox-label">
										<input type="checkbox" name="slotnova_weekly_off_days[]" value="<?php echo esc_attr( $day_key ); ?>" class="slotnova-checkbox-input" <?php checked( in_array( $day_key, $weekly_off, true ) ); ?> />
										<?php echo esc_html( $day_label ); ?>
									</label>
								<?php endforeach; ?>
							</fieldset>
							<p class="description"><?php esc_html_e( 'Select days of the week when your business is always closed.', 'slotnova-booking' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Specific Vacations', 'slotnova-booking' ); ?></th>
						<td>
							<input type="text" name="slotnova_specific_off_days" id="slotnova_specific_off_days" class="large-text" value="<?php echo esc_attr( get_option( 'slotnova_specific_off_days' ) ); ?>" />
							<p class="description"><?php esc_html_e( 'Select multiple specific dates you will be closed.', 'slotnova-booking' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render Product Data tab panel content.
	 *
	 * @return void
	 */
	public function render_slotnova_product_tab_content() {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
		global $post;
		?>
		<div id="slotnova_booking_data" class="panel woocommerce_options_panel show_if_slotnova">
			<div class="options_group">
				<h3><?php esc_html_e( 'Services', 'slotnova-booking' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Add services, drag to reorder them, and set their price.', 'slotnova-booking' ); ?></p>
				<?php
				$all_services   = get_terms( array( 'taxonomy' => 'slotnova_service', 'hide_empty' => false ) );
				$saved_services = get_post_meta( $post->ID, '_slotnova_product_services', true );
				if ( ! is_array( $saved_services ) ) {
					$saved_services = array();
				}
				?>
				<table class="wp-list-table widefat fixed striped slotnova-repeater-table" id="slotnova-services-table">
					<thead>
						<tr>
							<th width="5%" class="slotnova-align-center"></th>
							<th width="45%"><?php esc_html_e( 'Service', 'slotnova-booking' ); ?></th>
							<th width="40%"><?php esc_html_e( 'Price', 'slotnova-booking' ); ?></th>
							<th width="10%" class="slotnova-align-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! is_wp_error( $all_services ) ) : ?>
							<?php foreach ( $saved_services as $saved ) :
								$price = $saved['price'];
								if ( '' === $price || null === $price ) {
									$price = get_term_meta( $saved['term_id'], 'slotnova_service_price', true );
								}
								?>
								<tr>
									<td class="slotnova-drag-handle">☰</td>
									<td>
										<select name="slotnova_repeater_service_id[]" class="slotnova-table-select slotnova-service-select">
											<option value=""><?php esc_html_e( 'Select Service...', 'slotnova-booking' ); ?></option>
											<?php foreach ( $all_services as $service ) : ?>
												<option value="<?php echo esc_attr( $service->term_id ); ?>" <?php selected( $saved['term_id'], $service->term_id ); ?>><?php echo esc_html( $service->name ); ?></option>
											<?php endforeach; ?>
										</select>
									</td>
									<td>
										<input type="number" name="slotnova_repeater_service_price[]" value="<?php echo esc_attr( $price ); ?>" step="0.01" min="0" class="slotnova-table-input-price slotnova-service-price-input">
									</td>
									<td class="slotnova-align-center"><a href="#" class="slotnova-remove-row" title="<?php esc_attr_e( 'Remove', 'slotnova-booking' ); ?>"><span class="dashicons dashicons-trash"></span></a></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
				<p>
					<button type="button" class="button button-primary" id="slotnova-add-service"><?php esc_html_e( 'Add Service', 'slotnova-booking' ); ?></button>
				</p>
			</div>

			<div class="options_group">
				<h3><?php esc_html_e( 'Employees', 'slotnova-booking' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Add employees and drag to reorder them.', 'slotnova-booking' ); ?></p>
				<?php
				$all_employees   = get_terms( array( 'taxonomy' => 'slotnova_employee', 'hide_empty' => false ) );
				$saved_employees = get_post_meta( $post->ID, '_slotnova_product_employees', true );
				if ( ! is_array( $saved_employees ) ) {
					$saved_employees = array();
				}
				?>
				<table class="wp-list-table widefat fixed striped slotnova-repeater-table" id="slotnova-employees-table">
					<thead>
						<tr>
							<th width="5%" class="slotnova-align-center"></th>
							<th width="85%"><?php esc_html_e( 'Employee', 'slotnova-booking' ); ?></th>
							<th width="10%" class="slotnova-align-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! is_wp_error( $all_employees ) ) : ?>
							<?php foreach ( $saved_employees as $saved ) : ?>
								<tr>
									<td class="slotnova-drag-handle">☰</td>
									<td>
										<select name="slotnova_repeater_employee_id[]" class="slotnova-table-select">
											<option value=""><?php esc_html_e( 'Select Employee...', 'slotnova-booking' ); ?></option>
											<?php foreach ( $all_employees as $employee ) : ?>
												<option value="<?php echo esc_attr( $employee->term_id ); ?>" <?php selected( $saved['term_id'], $employee->term_id ); ?>><?php echo esc_html( $employee->name ); ?></option>
											<?php endforeach; ?>
										</select>
									</td>
									<td class="slotnova-align-center"><a href="#" class="slotnova-remove-row" title="<?php esc_attr_e( 'Remove', 'slotnova-booking' ); ?>"><span class="dashicons dashicons-trash"></span></a></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
				<p>
					<button type="button" class="button button-primary" id="slotnova-add-employee"><?php esc_html_e( 'Add Employee', 'slotnova-booking' ); ?></button>
				</p>
			</div>
		</div>

		<div id="slotnova_slot_manager_data" class="panel woocommerce_options_panel show_if_slotnova">
			<div class="options_group">
				<?php
				woocommerce_wp_select( array(
					'id'          => '_slotnova_enable_time_slots',
					'label'       => __( 'Enable Time Slots', 'slotnova-booking' ),
					'description' => __( 'Override the global time slots setting for this product.', 'slotnova-booking' ),
					'desc_tip'    => true,
					'options'     => array(
						'global' => __( 'Global Default', 'slotnova-booking' ),
						'yes'    => __( 'Yes (Enable)', 'slotnova-booking' ),
						'no'     => __( 'No (Disable)', 'slotnova-booking' ),
					),
				) );

				woocommerce_wp_text_input( array(
					'id'          => '_slotnova_opening_time',
					'label'       => __( 'Opening Time', 'slotnova-booking' ),
					'description' => __( 'Override global opening time (e.g., 09:00). Leave blank to use global settings.', 'slotnova-booking' ),
					'desc_tip'    => true,
					'type'        => 'time',
				) );

				woocommerce_wp_text_input( array(
					'id'          => '_slotnova_closing_time',
					'label'       => __( 'Closing Time', 'slotnova-booking' ),
					'description' => __( 'Override global closing time (e.g., 17:00). Leave blank to use global settings.', 'slotnova-booking' ),
					'desc_tip'    => true,
					'type'        => 'time',
				) );

				woocommerce_wp_text_input( array(
					'id'                => '_slotnova_slot_duration',
					'label'             => __( 'Slot Duration (Minutes)', 'slotnova-booking' ),
					'description'       => __( 'Duration in minutes. Leave blank to use global settings.', 'slotnova-booking' ),
					'desc_tip'          => true,
					'type'              => 'number',
					'custom_attributes' => array(
						'step' => '5',
						'min'  => '5',
					),
				) );
				?>
			</div>
			<div class="options_group">
				<h3><?php esc_html_e( 'Off-Days & Vacations', 'slotnova-booking' ); ?></h3>
				<p class="description"><?php esc_html_e( 'These will override the global off-days. Leave both blank to use global settings.', 'slotnova-booking' ); ?></p>

				<?php
				$saved_weekly = get_post_meta( $post->ID, '_slotnova_weekly_off_days', true );
				if ( ! is_array( $saved_weekly ) ) {
					$saved_weekly = array();
				}
				$days_of_week = array(
					'Sunday'    => __( 'Sunday', 'slotnova-booking' ),
					'Monday'    => __( 'Monday', 'slotnova-booking' ),
					'Tuesday'   => __( 'Tuesday', 'slotnova-booking' ),
					'Wednesday' => __( 'Wednesday', 'slotnova-booking' ),
					'Thursday'  => __( 'Thursday', 'slotnova-booking' ),
					'Friday'    => __( 'Friday', 'slotnova-booking' ),
					'Saturday'  => __( 'Saturday', 'slotnova-booking' ),
				);
				?>
				<p class="form-field">
					<label for="_slotnova_weekly_off_days"><?php esc_html_e( 'Weekly Off-Days', 'slotnova-booking' ); ?></label>
					<span class="slotnova-flex-checkbox-group">
					<?php foreach ( $days_of_week as $day_key => $day_label ) : ?>
						<label class="slotnova-checkbox-label">
							<input type="checkbox" name="_slotnova_weekly_off_days[]" value="<?php echo esc_attr( $day_key ); ?>" class="slotnova-checkbox-input" <?php checked( in_array( $day_key, $saved_weekly, true ) ); ?> />
							<?php echo esc_html( $day_label ); ?>
						</label>
					<?php endforeach; ?>
					</span>
				</p>
				<?php
				woocommerce_wp_text_input( array(
					'id'          => '_slotnova_specific_off_days',
					'label'       => __( 'Specific Vacations', 'slotnova-booking' ),
					'description' => __( 'Select multiple specific dates you will be closed.', 'slotnova-booking' ),
					'desc_tip'    => true,
				) );
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Save SlotNova product tab meta data.
	 *
	 * @param int $post_id Product post ID.
	 * @return void
	 */
	public function save_slotnova_product_tab_data( $post_id ) {
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['woocommerce_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woocommerce_meta_nonce'] ) ), 'woocommerce_save_data' ) ) {
			return;
		}

		$product_type = empty( $_POST['product-type'] ) ? 'simple' : sanitize_title( wp_unslash( $_POST['product-type'] ) );
		if ( 'slotnova' !== $product_type ) {
			return;
		}

		// Save Services
		$services_meta = array();
		$service_terms = array();
		if ( isset( $_POST['slotnova_repeater_service_id'] ) && is_array( $_POST['slotnova_repeater_service_id'] ) ) {
			$service_ids    = array_map( 'intval', wp_unslash( (array) $_POST['slotnova_repeater_service_id'] ) );
			$service_prices = isset( $_POST['slotnova_repeater_service_price'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['slotnova_repeater_service_price'] ) ) : array();

			foreach ( $service_ids as $index => $term_id ) {
				$term_id = intval( $term_id );
				if ( $term_id > 0 ) {
					$price           = isset( $service_prices[ $index ] ) ? sanitize_text_field( $service_prices[ $index ] ) : '';
					$services_meta[] = array(
						'term_id' => $term_id,
						'price'   => $price,
					);
					$service_terms[] = $term_id;
				}
			}
		}
		update_post_meta( $post_id, '_slotnova_product_services', $services_meta );
		wp_set_object_terms( $post_id, $service_terms, 'slotnova_service' );

		// Save Employees
		$employees_meta = array();
		$employee_terms = array();
		if ( isset( $_POST['slotnova_repeater_employee_id'] ) && is_array( $_POST['slotnova_repeater_employee_id'] ) ) {
			$employee_ids = array_map( 'intval', wp_unslash( (array) $_POST['slotnova_repeater_employee_id'] ) );

			foreach ( $employee_ids as $term_id ) {
				$term_id = intval( $term_id );
				if ( $term_id > 0 ) {
					$employees_meta[] = array( 'term_id' => $term_id );
					$employee_terms[] = $term_id;
				}
			}
		}
		update_post_meta( $post_id, '_slotnova_product_employees', $employees_meta );
		wp_set_object_terms( $post_id, $employee_terms, 'slotnova_employee' );

		// Save Slot Manager Data
		$opening_time = isset( $_POST['_slotnova_opening_time'] ) ? sanitize_text_field( wp_unslash( $_POST['_slotnova_opening_time'] ) ) : '';
		update_post_meta( $post_id, '_slotnova_opening_time', $opening_time );

		$closing_time = isset( $_POST['_slotnova_closing_time'] ) ? sanitize_text_field( wp_unslash( $_POST['_slotnova_closing_time'] ) ) : '';
		update_post_meta( $post_id, '_slotnova_closing_time', $closing_time );

		if ( isset( $_POST['_slotnova_slot_duration'] ) ) {
			update_post_meta( $post_id, '_slotnova_slot_duration', sanitize_text_field( wp_unslash( $_POST['_slotnova_slot_duration'] ) ) );
		}

		if ( isset( $_POST['_slotnova_enable_time_slots'] ) ) {
			update_post_meta( $post_id, '_slotnova_enable_time_slots', sanitize_text_field( wp_unslash( $_POST['_slotnova_enable_time_slots'] ) ) );
		} else {
			delete_post_meta( $post_id, '_slotnova_enable_time_slots' );
		}

		$weekly_off = isset( $_POST['_slotnova_weekly_off_days'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['_slotnova_weekly_off_days'] ) ) : array();
		update_post_meta( $post_id, '_slotnova_weekly_off_days', $weekly_off );

		$specific_off = isset( $_POST['_slotnova_specific_off_days'] ) ? sanitize_textarea_field( wp_unslash( $_POST['_slotnova_specific_off_days'] ) ) : '';
		update_post_meta( $post_id, '_slotnova_specific_off_days', $specific_off );
	}
}
